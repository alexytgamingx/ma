module.exports = {
  name: "Liezz",
  version: "4.1.0",
  number: "",
  owner: {
    name: "kinchan",
    number: "6285389296108",
    whatsapp: "6285389296108@s.whatsapp.net",
    instagram: "https://instagram.com/liezzaja",
  },
  author: {
    name: "zexs",
    number: "6285389296108",
    whatsapp: "6285389296108@s.whatsapp.net",
    instagram: "https://instagram.com/liezzaja",
  },
  features: {
    antiCall: {
      status: true,
      block: false,
    },
    selfMode: true,
    broadcast: {
      text: "",
      limit: 9999,
      jeda: 7000,
      filterContact: false,
    },
    pushContacts: {
      text: "",
      limit: 9999,
      jeda: 7000,
      filterContacts: false,
    },
  },
};
